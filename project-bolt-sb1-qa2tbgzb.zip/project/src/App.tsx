import React from 'react';
import { Newspaper, Search, Globe, Clock, TrendingUp, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2 text-2xl font-bold text-blue-600">
              <Newspaper className="h-8 w-8" />
              TaazaTime News
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-blue-600">Home</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">World</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Business</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Technology</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Sports</a>
            </nav>
            <div className="flex items-center gap-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search news..."
                  className="pl-10 pr-4 py-2 border rounded-full text-sm focus:outline-none focus:border-blue-500"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Breaking News Banner */}
      <div className="bg-red-600 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2">
            <span className="font-bold">BREAKING:</span>
            <span className="animate-marquee">Latest breaking news headlines appear here in a scrolling banner</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Featured Story */}
        <div className="mb-12">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative h-[400px]">
              <img
                src="https://images.unsplash.com/photo-1495020689067-958852a7765e"
                alt="Featured news"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div className="space-y-4">
              <span className="text-blue-600 font-semibold">Featured Story</span>
              <h1 className="text-4xl font-bold">Major Global Development Shapes International Relations</h1>
              <p className="text-gray-600 text-lg">
                Comprehensive coverage of the latest developments in international affairs and their impact on global politics and economics.
              </p>
              <div className="flex items-center gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>2 hours ago</span>
                </div>
                <div className="flex items-center gap-1">
                  <Globe className="h-4 w-4" />
                  <span>World News</span>
                </div>
              </div>
              <button className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700">
                Read More
              </button>
            </div>
          </div>
        </div>

        {/* Latest News Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {[1, 2, 3].map((item) => (
            <div key={item} className="bg-white rounded-lg shadow-md overflow-hidden">
              <img
                src={`https://images.unsplash.com/photo-${1590000000000 + item}`}
                alt={`News ${item}`}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <Clock className="h-4 w-4" />
                  <span>3 hours ago</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Important News Headline {item}</h3>
                <p className="text-gray-600 mb-4">
                  Brief description of the news story that provides context and key information...
                </p>
                <button className="text-blue-600 flex items-center gap-1 hover:text-blue-700">
                  Read Full Story <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Trending Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-12">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <h2 className="text-2xl font-bold">Trending Stories</h2>
          </div>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((item) => (
              <div key={item} className="flex items-center gap-4 pb-4 border-b last:border-0">
                <span className="text-2xl font-bold text-blue-600">{item}</span>
                <div>
                  <h3 className="font-semibold mb-1">Trending News Headline {item}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>2k reads</span>
                    <span>•</span>
                    <span>5 hours ago</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 text-2xl font-bold mb-4">
                <Newspaper className="h-8 w-8" />
                TaazaTime News
              </div>
              <p className="text-gray-400">
                Your trusted source for the latest news and updates from around the world.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Categories</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">World</a></li>
                <li><a href="#" className="hover:text-white">Business</a></li>
                <li><a href="#" className="hover:text-white">Technology</a></li>
                <li><a href="#" className="hover:text-white">Sports</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Advertise</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Twitter</a></li>
                <li><a href="#" className="hover:text-white">Facebook</a></li>
                <li><a href="#" className="hover:text-white">Instagram</a></li>
                <li><a href="#" className="hover:text-white">LinkedIn</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 TaazaTime News. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;